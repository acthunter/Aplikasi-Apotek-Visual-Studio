-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jan 2019 pada 02.34
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbapotik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_dokter`
--

CREATE TABLE `tbl_dokter` (
  `kodedokter` varchar(15) NOT NULL,
  `namadokter` varchar(25) NOT NULL,
  `haripraktek` varchar(40) NOT NULL,
  `nohp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_dokter`
--

INSERT INTO `tbl_dokter` (`kodedokter`, `namadokter`, `haripraktek`, `nohp`) VALUES
('D001', 'Sumanto', 'Minggu', '08324'),
('D002', 'Upin', 'Sabtu', '08356'),
('D003', 'Ipin', 'Senin', '08345'),
('D004', 'Sule', 'Selasa', '08329'),
('D005', 'Andre', 'Rabu', '08334'),
('D006', 'Carl', 'Kamis', '08343');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_login`
--

CREATE TABLE `tbl_login` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `level` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_login`
--

INSERT INTO `tbl_login` (`username`, `password`, `level`) VALUES
('apoteker', 'apoteker', 'apoteker'),
('pimpinan', 'pimpinan', 'pimpinan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_obat`
--

CREATE TABLE `tbl_obat` (
  `kodeobat` varchar(15) NOT NULL,
  `namaobat` varchar(15) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_obat`
--

INSERT INTO `tbl_obat` (`kodeobat`, `namaobat`, `harga`) VALUES
('KO1', 'Paracetamol', 15000),
('KO2', 'Antalgin', 3000),
('KO3', 'CTM', 6000),
('KO4', 'Inza', 4000),
('KO5', 'Bodrex', 5000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pembeli`
--

CREATE TABLE `tbl_pembeli` (
  `kodepembeli` varchar(15) NOT NULL,
  `namapembeli` varchar(25) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `alamat` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_pembeli`
--

INSERT INTO `tbl_pembeli` (`kodepembeli`, `namapembeli`, `nohp`, `alamat`) VALUES
('001', 'Kambing', '0893249', 'Meikarta'),
('002', 'Tanos', '08324', 'Wakanda'),
('003', 'dayang', '082382750763', 'pessel');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `notransaksi` varchar(3) NOT NULL,
  `hari` varchar(7) NOT NULL,
  `namadokter` varchar(25) NOT NULL,
  `kodeobat` varchar(10) NOT NULL,
  `namaobat` varchar(30) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlahbeli` int(11) NOT NULL,
  `totalharga` int(11) NOT NULL,
  `uangbayar` int(11) NOT NULL,
  `kembalian` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`notransaksi`, `hari`, `namadokter`, `kodeobat`, `namaobat`, `harga`, `jumlahbeli`, `totalharga`, `uangbayar`, `kembalian`) VALUES
('001', 'Senin', 'Ipin', 'KO1', 'Paracetamol', 15000, 2, 30000, 100000, 70000),
('123', 'Kamis', 'Carl', 'KO2', 'Antalgin', 3000, 3, 9000, 50000, 41000),
('234', 'Minggu', 'Sumanto', 'KO1', 'Paracetamol', 15000, 2, 30000, 100000, 70000),
('342', 'Sabtu', 'Upin', 'KO3', 'CTM', 6000, 2, 12000, 15000, 3000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_dokter`
--
ALTER TABLE `tbl_dokter`
  ADD PRIMARY KEY (`kodedokter`);

--
-- Indeks untuk tabel `tbl_obat`
--
ALTER TABLE `tbl_obat`
  ADD PRIMARY KEY (`kodeobat`);

--
-- Indeks untuk tabel `tbl_pembeli`
--
ALTER TABLE `tbl_pembeli`
  ADD PRIMARY KEY (`kodepembeli`);

--
-- Indeks untuk tabel `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`notransaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
