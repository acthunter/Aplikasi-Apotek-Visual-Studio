﻿Public Class ltransaksi


    Private Sub ltransaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    End Sub
End Class