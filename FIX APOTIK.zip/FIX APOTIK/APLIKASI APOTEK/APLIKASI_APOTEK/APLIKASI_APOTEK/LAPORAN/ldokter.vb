﻿Public Class ldokter

    Private Sub ldokter_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
   

    End Sub

    Private Sub ReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class