﻿Public Class menu_program

    Private Sub KELUARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KELUARToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub INPUTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles INPUTToolStripMenuItem.Click

    End Sub

    Private Sub InputDataObatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputDataObatToolStripMenuItem.Click
        dataobat.Show()
    End Sub

    Private Sub InputDataPembeliToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputDataPembeliToolStripMenuItem.Click
        datapembeli.Show()
    End Sub

    Private Sub InputTransaksiPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputTransaksiPenjualanToolStripMenuItem.Click
        datatransaksi.Show()
    End Sub

    Private Sub InputDataDokterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputDataDokterToolStripMenuItem.Click
        datadokter.Show()
    End Sub

    Private Sub LaporanDataObatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanDataObatToolStripMenuItem.Click
        lobat.Show()
    End Sub

    Private Sub LaporanDataPembeliToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanDataPembeliToolStripMenuItem.Click
        lpembeli.Show()
    End Sub

    Private Sub LAPORANTRANSAKSIPENJUALANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LAPORANTRANSAKSIPENJUALANToolStripMenuItem.Click
        ltransaksi.Show()
    End Sub
End Class