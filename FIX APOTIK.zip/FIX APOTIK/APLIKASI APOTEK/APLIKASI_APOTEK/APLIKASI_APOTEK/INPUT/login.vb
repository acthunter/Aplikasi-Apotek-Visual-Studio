﻿Imports MySql.Data.MySqlClient
Public Class login

    Private Sub login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi_oke()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username, password, level As String
        username = vuser.Text
        password = vpas.Text
        level = clevel.SelectedItem
        sql = "select * from tbl_login where username='" + username + "' and password='" + password + "' and level='" + level + "'"
        cmd = New MySqlCommand(sql, conn)
        rd = cmd.ExecuteReader
        If rd.HasRows = True Then
            If level = "apoteker" Then
                menu_program.InputDataObatToolStripMenuItem.Enabled = True
                menu_program.InputDataPembeliToolStripMenuItem.Enabled = True
                menu_program.InputTransaksiPenjualanToolStripMenuItem.Enabled = True
                menu_program.InputDataDokterToolStripMenuItem.Enabled = False
                menu_program.LaporanDataObatToolStripMenuItem.Enabled = False
                menu_program.LaporanDataPembeliToolStripMenuItem.Enabled = False
                menu_program.LAPORANTRANSAKSIPENJUALANToolStripMenuItem.Enabled = False
                menu_program.Show()
                Me.Hide()
            ElseIf level = "pimpinan" Then
                menu_program.InputDataObatToolStripMenuItem.Enabled = False
                menu_program.InputDataPembeliToolStripMenuItem.Enabled = False
                menu_program.InputTransaksiPenjualanToolStripMenuItem.Enabled = False
                menu_program.LaporanDataObatToolStripMenuItem.Enabled = True
                menu_program.LaporanDataPembeliToolStripMenuItem.Enabled = True
                menu_program.LAPORANTRANSAKSIPENJUALANToolStripMenuItem.Enabled = True
                menu_program.Show()
                Me.Hide()
            End If
        Else
            MessageBox.Show("Password dan hak akses salah", "Pemberitahuan", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        rd.Close()
        cmd.Dispose()
    End Sub
End Class