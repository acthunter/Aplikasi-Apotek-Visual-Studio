﻿Imports MySql.Data.MySqlClient
Public Class dataobat

    Private Sub dataobat_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi_oke()
        Call tampil()
    End Sub

    Public Sub tampil()
        da = New MySqlDataAdapter("SELECT * FROM tbl_obat", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "tbl_obat")
        tabelobat.DataSource = (ds.Tables("tbl_obat"))

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            sql = "INSERT INTO tbl_obat VALUES('" & vkode.Text & "', '" & vnama.Text & "', '" & vharga.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        vkode.Text = ""
        vnama.Text = ""
        vharga.Text = ""

       
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
       
        Dim Obat = InputBox("Masukkan Kode Obat")
        Try
            ds.Tables(0).PrimaryKey = New DataColumn() {ds.Tables(0).Columns("kodeobat")}
            Dim row As DataRow
            row = ds.Tables(0).Rows.Find(Obat)
            vkode.Text = row("kodeobat")
            vnama.Text = row("namaobat")
            vharga.Text = row("harga")
            
        Catch ex As Exception
            MsgBox("Data Tidak ada / anda batal mencari Data !!")
        End Try

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim hapus As String
        hapus = "delete from tbl_obat where kodeobat='" & vkode.Text & "'"
        cmd = New MySqlCommand(hapus, conn)
        cmd.ExecuteNonQuery()
        MsgBox("DATA SUDAH TERHAPUS", MsgBoxStyle.Information, "INFORMASI")
        vkode.Enabled = True
        Call tampil()
    End Sub
End Class