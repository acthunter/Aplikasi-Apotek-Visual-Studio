﻿Imports MySql.Data.MySqlClient

Public Class datapembeli

    Private Sub datapembeli_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi_oke()
        Call tampil()
    End Sub

    Public Sub tampil()
        da = New MySqlDataAdapter("SELECT * FROM tbl_pembeli", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "tbl_pembeli")
        tabelpembeli.DataSource = (ds.Tables("tbl_pembeli"))

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        vnama.Text = ""
        vkode.Text = ""
        vnohp.Text = ""
        valamat.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            sql = "INSERT INTO tbl_pembeli VALUES('" & vkode.Text & "', '" & vnama.Text & "', '" & vnohp.Text & "', '" & valamat.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try
    End Sub

    Private Sub tabelpembeli_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles tabelpembeli.CellContentClick

    End Sub
End Class