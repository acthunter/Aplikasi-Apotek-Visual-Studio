﻿Imports MySql.Data.MySqlClient
Public Class datadokter

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Public Sub tampil()
        da = New MySqlDataAdapter("SELECT * FROM tbl_dokter", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "tbl_dokter")
        tabeldokter.DataSource = (ds.Tables("tbl_dokter"))

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        vnama.Text = ""
        vkode.Text = ""
        vnohp.Text = ""
        Vpraktek.Text = ""
    End Sub

    Private Sub datadokter_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi_oke()
        Call tampil()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            sql = "INSERT INTO tbl_dokter VALUES('" & vkode.Text & "', '" & vnama.Text & "','" & Vpraktek.Text & "','" & vnohp.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim hapus As String
        hapus = "delete from tbl_dokter where kodedokter='" & vkode.Text & "'"
        cmd = New MySqlCommand(hapus, conn)
        cmd.ExecuteNonQuery()
        MsgBox("DATA SUDAH TERHAPUS", MsgBoxStyle.Information, "INFORMASI")
        vkode.Enabled = True
        Call tampil()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim Dokter = InputBox("Masukkan Kode Dokter")
        Try
            ds.Tables(0).PrimaryKey = New DataColumn() {ds.Tables(0).Columns("kodedokter")}
            Dim row As DataRow
            row = ds.Tables(0).Rows.Find(Dokter)
            vkode.Text = row("kodedokter")
            vnama.Text = row("namadokter")
            Vpraktek.Text = row("haripraktek")
            vnohp.Text = row("nohp")

        Catch ex As Exception
            MsgBox("Data Tidak ada / anda batal mencari Data !!")
        End Try
    End Sub
End Class