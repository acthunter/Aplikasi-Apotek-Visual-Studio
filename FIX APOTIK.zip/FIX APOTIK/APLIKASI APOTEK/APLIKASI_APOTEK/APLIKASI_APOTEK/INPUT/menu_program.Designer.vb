﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menu_program
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(menu_program))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.INPUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputDataObatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputDataPembeliToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputTransaksiPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputDataDokterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LAPORANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanDataObatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanDataPembeliToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LAPORANTRANSAKSIPENJUALANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KELUARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.MenuStrip1.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INPUTToolStripMenuItem, Me.LAPORANToolStripMenuItem, Me.KELUARToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(677, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'INPUTToolStripMenuItem
        '
        Me.INPUTToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InputDataObatToolStripMenuItem, Me.InputDataPembeliToolStripMenuItem, Me.InputTransaksiPenjualanToolStripMenuItem, Me.InputDataDokterToolStripMenuItem})
        Me.INPUTToolStripMenuItem.Name = "INPUTToolStripMenuItem"
        Me.INPUTToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.INPUTToolStripMenuItem.Text = "INPUT"
        '
        'InputDataObatToolStripMenuItem
        '
        Me.InputDataObatToolStripMenuItem.Name = "InputDataObatToolStripMenuItem"
        Me.InputDataObatToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.InputDataObatToolStripMenuItem.Text = "INPUT DATA OBAT"
        '
        'InputDataPembeliToolStripMenuItem
        '
        Me.InputDataPembeliToolStripMenuItem.Name = "InputDataPembeliToolStripMenuItem"
        Me.InputDataPembeliToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.InputDataPembeliToolStripMenuItem.Text = "INPUT DATA PEMBELI"
        '
        'InputTransaksiPenjualanToolStripMenuItem
        '
        Me.InputTransaksiPenjualanToolStripMenuItem.Name = "InputTransaksiPenjualanToolStripMenuItem"
        Me.InputTransaksiPenjualanToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.InputTransaksiPenjualanToolStripMenuItem.Text = "INPUT TRANSAKSI PENJUALAN"
        '
        'InputDataDokterToolStripMenuItem
        '
        Me.InputDataDokterToolStripMenuItem.Name = "InputDataDokterToolStripMenuItem"
        Me.InputDataDokterToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.InputDataDokterToolStripMenuItem.Text = "INPUT DATA DOKTER"
        '
        'LAPORANToolStripMenuItem
        '
        Me.LAPORANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanDataObatToolStripMenuItem, Me.LaporanDataPembeliToolStripMenuItem, Me.LAPORANTRANSAKSIPENJUALANToolStripMenuItem})
        Me.LAPORANToolStripMenuItem.Name = "LAPORANToolStripMenuItem"
        Me.LAPORANToolStripMenuItem.Size = New System.Drawing.Size(81, 20)
        Me.LAPORANToolStripMenuItem.Text = "LAPORAN"
        '
        'LaporanDataObatToolStripMenuItem
        '
        Me.LaporanDataObatToolStripMenuItem.Name = "LaporanDataObatToolStripMenuItem"
        Me.LaporanDataObatToolStripMenuItem.Size = New System.Drawing.Size(291, 22)
        Me.LaporanDataObatToolStripMenuItem.Text = "LAPORAN DATA OBAT"
        '
        'LaporanDataPembeliToolStripMenuItem
        '
        Me.LaporanDataPembeliToolStripMenuItem.Name = "LaporanDataPembeliToolStripMenuItem"
        Me.LaporanDataPembeliToolStripMenuItem.Size = New System.Drawing.Size(291, 22)
        Me.LaporanDataPembeliToolStripMenuItem.Text = "LAPORAN DATA PEMBELI"
        '
        'LAPORANTRANSAKSIPENJUALANToolStripMenuItem
        '
        Me.LAPORANTRANSAKSIPENJUALANToolStripMenuItem.Name = "LAPORANTRANSAKSIPENJUALANToolStripMenuItem"
        Me.LAPORANTRANSAKSIPENJUALANToolStripMenuItem.Size = New System.Drawing.Size(291, 22)
        Me.LAPORANTRANSAKSIPENJUALANToolStripMenuItem.Text = "LAPORAN TRANSAKSI PENJUALAN"
        '
        'KELUARToolStripMenuItem
        '
        Me.KELUARToolStripMenuItem.Name = "KELUARToolStripMenuItem"
        Me.KELUARToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.KELUARToolStripMenuItem.Text = "KELUAR"
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.AutoSize = True
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(475, 343)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(467, 196)
        Me.Panel1.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Lucida Bright", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(82, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(325, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "PENDIDIKAN TEKNOLOGI INFORMASI"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Lucida Bright", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(209, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 20)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "2019"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Lucida Bright", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(136, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "NAMA    :  DAYANG MAISARI"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Lucida Bright", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(29, 124)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(412, 20)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "UNIVERSITAS PUTRA INDONESIA YPTK PADANG"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Lucida Bright", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(118, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(250, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "NO BP        : 17101152610020"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'menu_program
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(677, 375)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "menu_program"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "APLIKASI APOTEKER"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents INPUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputDataObatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputDataPembeliToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputTransaksiPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputDataDokterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPORANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanDataObatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanDataPembeliToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KELUARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPORANTRANSAKSIPENJUALANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
