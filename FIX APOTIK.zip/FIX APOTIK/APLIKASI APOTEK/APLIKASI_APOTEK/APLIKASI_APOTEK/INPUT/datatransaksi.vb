﻿Imports MySql.Data.MySqlClient
Imports System.EventArgs
Public Class datatransaksi

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Public Sub tampil()
        da = New MySqlDataAdapter("SELECT * FROM tbl_transaksi", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "tbl_transaksi")
        tabeltransaksi.DataSource = (ds.Tables("tbl_transaksi"))

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        
        If ComboBox1.Text = "KO1" Then
            vnmobat.Text = "Paracetamol"
            vharga.Text = "15000"

        ElseIf ComboBox1.Text = "KO2" Then
            vnmobat.Text = "Antalgin"
            vharga.Text = "3000"

        ElseIf ComboBox1.Text = "KO3" Then
            vnmobat.Text = "CTM"
            vharga.Text = "6000"

        Else
            ComboBox1.Text = "KO4"
            vnmobat.Text = "Inza"
            vharga.Text = "4000"
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            sql = "INSERT INTO tbl_transaksi VALUES('" & vno.Text & "', '" & ComboBox2.Text & "', '" & vnmdokter.Text & "', '" & ComboBox1.Text & "', '" & vnmobat.Text & "', '" & vharga.Text & "', '" & vjml.Text & "', '" & vttl.Text & "', '" & vbayar.Text & "', '" & vkembali.Text & "')"
            cmd = New MySqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data Gagal Disimpan")
        End Try
    End Sub

    Private Sub datatransaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi_oke()
        Call tampil()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.Text = "Senin" Then
            vnmdokter.Text = "Ipin"

        ElseIf ComboBox2.Text = "Selasa" Then
            vnmdokter.Text = "Sule"

        ElseIf ComboBox2.Text = "Rabu" Then
            vnmdokter.Text = "Andre"

        ElseIf ComboBox2.Text = "Kamis" Then
            vnmdokter.Text = "Carl"

        ElseIf ComboBox2.Text = "Sabtu" Then
            vnmdokter.Text = "Upin"

        Else
            ComboBox2.Text = "Minggu"
            vnmdokter.Text = "Sumanto"
        End If
    End Sub

    Private Sub vjml_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles vjml.KeyPress
        If e.KeyChar = Chr(13) Then
            vttl.Text = vjml.Text * vharga.Text
        End If

    End Sub

    Private Sub vjml_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vjml.TextChanged
       
    End Sub

    Private Sub vkembali_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkembali.TextChanged
       
    End Sub

    Private Sub vbayar_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles vbayar.KeyDown

    End Sub

    Private Sub vbayar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles vbayar.KeyPress
        If e.KeyChar = Chr(13) Then
            vkembali.Text = vbayar.Text - vttl.Text
        End If
    End Sub

    Private Sub vbayar_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vbayar.TextChanged

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        Dim Transaksi = InputBox("Masukkan Nomor Transaksi")
        Try
            ds.Tables(0).PrimaryKey = New DataColumn() {ds.Tables(0).Columns("notransaksi")}
            Dim row As DataRow
            row = ds.Tables(0).Rows.Find(Transaksi)
            vno.Text = row("notransaksi")
            ComboBox2.Text = row("hari")
            vnmdokter.Text = row("namadokter")
            ComboBox1.Text = row("kodeobat")
            vnmobat.Text = row("namaobat")
            vharga.Text = row("harga")
            vjml.Text = row("jumlahbeli")
            vttl.Text = row("totalharga")
            vbayar.Text = row("uangbayar")
            vkembali.Text = row("kembalian")

        Catch ex As Exception
            MsgBox("Data Tidak ada / anda batal mencari Data !!")
        End Try

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim hapus As String
        hapus = "delete from tbl_transaksi where notransaksi='" & vno.Text & "'"
        cmd = New MySqlCommand(hapus, conn)
        cmd.ExecuteNonQuery()
        MsgBox("DATA SUDAH TERHAPUS", MsgBoxStyle.Information, "INFORMASI")
        vno.Enabled = True
        Call tampil()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        vno.Text = ""
        ComboBox2.Text = ""
        vnmdokter.Text = ""
        ComboBox1.Text = ""
        vnmobat.Text = ""
        vharga.Text = ""
        vjml.Text = ""
        vttl.Text = ""
        vbayar.Text = ""
        vkembali.Text = ""
    End Sub
End Class